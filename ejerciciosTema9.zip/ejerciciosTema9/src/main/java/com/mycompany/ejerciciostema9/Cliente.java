/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciostema9;

/**
 *
 * @author bbva
 */
public class Cliente extends Persona{
    
    private String credito;

    public Cliente(String credito, String nombre, String telefono, int edad) {
        super(nombre, telefono, edad);
        this.credito = credito;
    }

    public Cliente() {
    }

    /**
     * @return the credito
     */
    public String getCredito() {
        return credito;
    }

    /**
     * @param credito the credito to set
     */
    public void setCredito(String credito) {
        this.credito = credito;
    }
    
    public static void main(String[] args) {
        
        Cliente cliente = new Cliente();
        
        cliente.setNombre("Faver");
        cliente.setEdad(31);
        cliente.setTelefono("1234567");
        cliente.setCredito("Libre Inversion");
        
        System.out.println("Su Nombre Es: " + cliente.getNombre());
        System.out.println("Su Edad Es: " + cliente.getEdad() + " Años");
        System.out.println("Su Telefono Es: " + cliente.getTelefono());
        System.out.println("Su Credito Es: " + cliente.getCredito());
    }
    
}
