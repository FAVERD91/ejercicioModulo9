/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciostema9;

/**
 *
 * @author bbva
 */
public class Trabajdor extends Persona{
    
    private int salario;

    public Trabajdor() {
    }

    public Trabajdor(int salario, String nombre, String telefono, int edad) {
        super(nombre, telefono, edad);
        this.salario = salario;
    }

    /**
     * @return the salario
     */
    public int getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(int salario) {
        this.salario = salario;
    }
    
    
    
    
    
}
